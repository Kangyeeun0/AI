import random
import math
import numpy as np
import csv
import matplotlib.pyplot as plt
import time
from math import dist
import pandas as pd
import sys
import copy

csvfile = '2023_AI_TSP.csv'                 #파일로부터 좌표 읽어오기
cityCoordinates = pd.read_csv(csvfile, header = None)
cityCoordinates = cityCoordinates.values.tolist()
cityCoordinates_copy = copy.deepcopy(cityCoordinates)

def xyToIdx(original, path_list):   #xy 좌표를 idx로 변환
    #print(len( original ), len(path_list))
    order_list = []
    for i in range(len(path_list)):
        for j in range(len(original)):
            if path_list[i] == original[j]:
                order_list.append(j)
                break
    return order_list

def idxToXy(original, path_idx):    #idx를 xy 좌표로 변환
    path_list = []
    for i in range(len(path_idx)):
        #print(len(original), path_idx[i])
        path_list.append(original[path_idx[i]])
    return path_list

class Visualizer:
    x_list = []
    y_list = []
    sort_list = []
    length = -1
    total_length = 0      #TSP 순회 거리 저장
    
    def __init__(self, solutionList = None):
        if solutionList == None:
            self.length = 1000
            print("LOADED FROM FILE DATA")
            f = open("./example_solution.csv", "rt", encoding = "UTF-8")    #탐색해야 하는 우선순위 -> sort_list에 저장
            sort_data = csv.reader(f)
            for row in sort_data:
                self.sort_list.append(float(row[0]))                           # 테스트를 위한 코드. 합친 뒤에는 GA의 결과 리스트로 대체
        else :
            self.length = len(solutionList)
            self.sort_list = solutionList
            
            for i in self.sort_list:
                self.x_list.append(cityCoordinates[i][0])
                self.y_list.append(cityCoordinates[i][1])
                #print("APPENDED : ", (cityCoordinates[i][0], cityCoordinates[i][1]), "\n")
        
    def visualize(self):
        plt.figure(figsize = (7, 7))    #plot 크기 조절
        plt.grid(True, axis = 'x')  #x축 grid 표시
        plt.grid(True, axis = 'y')  #y축 grid 표시

        #case1) 점만 표현하기
        #for i in range(0, self.length):
        #    if(i == 0):
        #        plt.plot(float(x_list[i]), float(y_list[i]), color = "violet", marker = ".", markerfacecolor = "red", markersize = 8)
        #    else:
        #        plt.plot(float(x_list[i]), float(y_list[i]), color = "skyblue", marker = ".", markerfacecolor = "blue", markersize = 8)

        #case2) 점과 선 모두 표현하기
        for i in range(0, self.length): # 0 ~ length - 1
            if(i == 0): # 시작점
                plt.plot(self.x_list[i], self.y_list[i], color = "violet", marker = ".", markerfacecolor = "red", markersize = 8)  #시작점은 빨간점으로 표시
            elif i == self.length - 1:
                plt.plot((self.x_list[i-1], self.x_list[i]), (self.y_list[i - 1], self.y_list[i]), color = "skyblue", marker = ".", markerfacecolor = "blue", markersize = 8, linewidth = 0.5)
                plt.plot((self.x_list[i], self.x_list[0]), (self.y_list[i], self.y_list[0]), color = "skyblue", marker = ".", markerfacecolor = "blue", markersize = 8, linewidth = 0.5)
            else:   
                plt.plot((self.x_list[i-1], self.x_list[i]), (self.y_list[i - 1], self.y_list[i]), color = "skyblue", marker = ".", markerfacecolor = "blue", markersize = 8, linewidth = 0.5)  #순회를 다 마쳤으면 시작점으로 돌아옴
            if(i >= 1):
                if(i == self.length ):
                    self.total_length += (abs((self.x_list[i] - self.x_list[0]))**2 + (abs(self.y_list[i] - self.y_list[0]))**2)**(1/2)  #순회를 마치고 시작점으로 돌아가는 길이도 누적
                else:
                    self.total_length += (abs((self.x_list[i] - self.x_list[i - 1]))**2 + (abs(self.y_list[i] - self.y_list[i - 1]))**2)**(1/2)  #각 경로의 길이를 누적  
        plt.plot(self.x_list[0], self.y_list[0], color = "violet", marker = ".", markerfacecolor = "red", markersize = 8)   
        plt.xlim(-5, 105)   #x범위 지정
        plt.ylim(-5, 105)   #y범위 지정

        plt.title("Visualization of TSP Cities                Total_length ≒ " + str(int(self.total_length)))    #시각화 제목 + total_length 나타냄

        plt.savefig("Visualization_of_TSP_Cities.png", dpi = 600) #시각화 저장

        plt.show()  #시각화 출력
        return


class GenerateChromo():
    def __init__(self, sampleNum = 49):
        self.cityCoordinates_sample = random.sample(cityCoordinates, sampleNum) # sampleNum + 1개의 좌표를 샘플링
        self.cityCoordinates_sample.insert(0, cityCoordinates[0])
        self.path = []
        
    def generate(self):
        self.path = self.tsp(self.cityCoordinates_sample)
        threshold = random.randint(0, 10)

        subSet = [x for x in cityCoordinates if x not in self.cityCoordinates_sample] # -> 900개 생성
        for i in subSet:
            tempDist = 0
            bestDist = 0
            tempIdx = 0
            for j in range(len(self.path)):
                tempDist = math.dist(self.path[j], i)
                if tempDist < bestDist: # best distance를 기록
                    bestDist = tempDist
                    tempIdx = j
                if tempDist <= threshold: # 거리가 threshold보다 작다면 그 다음 index에 추가
                    self.path.insert(j+1, i)
                    break
                if j == len(self.path) - 1: # 거리가 threshold보다 작은게 없다면 거리가 최소인 index 뒤에 추가
                    self.path.insert(tempIdx + 1, i)
                    break

        #print(len(path))
        return self.path # xy 좌표
    
    #2-opt
    def evaluate(self, path_):
        return sum(math.dist(path_[i], path_[i+1]) for i in range(len(path_)-1))

    def two_opt(self, path_): # 2-opt 함수
        n = len(path_)
        improvement = True
        while improvement:
            improvement = False
            for i in range(1, n-2):
                for j in range(i+1, n):
                    if j-i == 1:
                        continue
                    new_path = path_[:]
                    new_path[i:j] = path_[j-1:i-1:-1]
                    if self.evaluate(new_path) < self.evaluate(path_):
                        path_ = new_path
                        improvement = True
            if improvement == False:
                break
        return path_

    def tsp(self, coordinates):
        path_ = coordinates[:]
        path_.append(path_[0])
        path_ = self.two_opt(path_)
        return path_
    

class CityList:
    mutationCount = 2
    chromosomes=[]
    fitness=-1
    numberOfChromosomes = 16    #랜덤생성시 chromosomes 길이. n일 경우 n+1개의 순서열이 생성(시작 노드는 시작과 끝에 하나씩 배치됨)

    def __init__(self, mutCnt = 2, chromo = None, opt = 2): # opt -> 0 : chromo를 염색체로 사용
        if mutCnt != 2:                                      #      | 1 : 랜덤 순서 염색체
            mutationCount = mutCnt                           #      | 2 : 빈 염색체
        if opt == 1:
            self.chromosomes = list(range(self.numberOfChromosomes)) # numOfChromo...이 1000일 경우 999까지 생성
            random.shuffle(self.chromosomes)
            self.appendChromo(self.chromosomes[0]) # 시작점과 도착점을 동일하게 설정
            #print("GENERATED_CHROMOSOME")
            #print(self.chromosomes)
        elif opt == 0:
            if chromo[0] != chromo[len(chromo)-1]:
                print("FROM 'CityList.__init__()' WRONG NUMBER GIVEN") # 입력 염색체의 시작과 끝이 같은지 비교
                sys.exit()
            else:
                self.chromosomes = chromo    #헤밀토니안 결과에서 시작점과 도착점이 동일한지 여부에 따라 수정 필요할 수 있음
                #print(self.chromosome)
        elif opt == 2:
            None
        else:
            print("FROM 'CityList.__init__()' ENTERED WRONG OPTION")
            sys.exit()
        self.calculateFitness()
            
                
    def getChromo(self):
        return self.chromosomes
    
    def changeChromo(self, chromo):
        self.chromosomes = chromo
        self.calculateFitness()
        return

    def mutation(self):
        self.chromosomes = self.chromosomes[0:len(self.chromosomes)-1] # 마지막 노드 제거
        """for x in range(self.mutationCount):       # 일정 구간 반전
            p1 = random.randrange(1, len(self.chromosomes) - 1)
            p2 = random.randrange(1, len(self.chromosomes) - 1)
            while p1==p2 or p1>p2:
                p1=random.randint(0, len(self.chromosomes)-1)
                p2=random.randint(0, len(self.chromosomes)-1)
            log = self.chromosomes[p1:p2]
            log = log[::-1]
            self.chromosomes = self.chromosomes[:p1] + log + self.chromosomes[p2:]"""
        randNum = random.randint(0, 3)
        if randNum == 0:
            mutidx = random.sample(range(len(self.chromosomes)), 10)    #염기 10개 재배치(25%)
            mutList = []
            for i in range(10):
                mutList.append(self.chromosomes[mutidx[i]])
            random.shuffle(mutidx)
            for j in range(10):
                self.chromosomes[mutidx[j]] = mutList[j]
        elif randNum == 1 :
            mutationLen = 10                         #길이 10인 랜덤한 구간을 잡아 재배열(25%)
            for i in range(5):
                start = random.randint(0, len(self.chromosomes) - 10)
                innerSet = self.chromosomes[start:start + mutationLen]
                startSet = self.chromosomes[:start]
                endSet = self.chromosomes[start + mutationLen:]

                random.shuffle(innerSet)
                self.chromosome = startSet + innerSet + endSet
        else:                                       #10개 지점의 염기서열을 각각 주변의 것과 교환(50%)
            mutCnt = random.randint(1, 16)
            for i in range(mutCnt):
                idx = random.randint(10, len(self.chromosomes) - 11)
                pnt = random.randint(-10, 10)
                while pnt == 0:
                    pnt = random.randint(-10, 10)
                #print(len(self.chromosomes), idx, pnt)
                temp = self.chromosomes[idx]
                self.chromosomes[idx] = self.chromosomes[idx + pnt]
                self.chromosomes[idx + pnt] = temp
            
        self.appendChromo(self.chromosomes[0])                     #마지막 노드 다시 추가
        return

    def calculateFitness(self):
        Fitness = 0
        #print(len(cityCoordinates), len(self.chromosomes))
        #print(self.chromosomes)
        for i in range(len(self.chromosomes)-1): # 0 ~ 999
            p1 = cityCoordinates[self.chromosomes[i]]
            p2 = cityCoordinates[self.chromosomes[i + 1]]
            Fitness += dist(p1, p2)
        Fitness = np.round(Fitness, 2)
        self.fitness = Fitness
        #print(self.fitness)
        return self.fitness

    def getFitness(self):
        return self.fitness
    
    def appendChromo(self, chromo):
        self.chromosomes.append(chromo)
        return
    
    def printChromo(self, opt = 0): #0 : 모든 fitness, 염색체 출력, 1 : fitness만 출력
        if opt == 0:
            print("FITNESS : ", self.fitness, "\t CHROMO : ", self.chromosomes, "\n")
        else:
            print("FITNESS : ", self.fitness)
        return
    
 
class Population:
    pop = []
    maxPopSize = 0
    curPopSize = 0
    generation = 0
    mutationRate = 40    # %
    
    def __init__(self, size = 10, chromoList = None):
        self.maxPopSize = size
        if chromoList == None:
            while self.curPopSize <= self.maxPopSize:
                temp = CityList(2, None, 1) #숫자열을 랜덤으로 생성. 해밀토니안 적용 시 수정 필요(1을 0으로 수정)
                self.pop.append(temp)
                self.curPopSize += 1
        else:
            if self.maxPopSize != len(chromoList):
                self.maxPopSize = len(chromoList)
            while self.curPopSize < self.maxPopSize:
                #print(self.curPopSize, " / ", self.maxPopSize)
                temp = CityList(2, chromoList[self.curPopSize], 0)
                self.pop.append(temp)
                self.curPopSize += 1
        return
        
    def printPop(self, opt = 0): #0 : 모든 fitness, 염색체 출력, 1 : fitness만 출력
        if opt == 0:
            for chromo in self.pop:
                chromo.printChromo(0)
        else:
            for chromo in self.pop:
                chromo.printChromo(1)
        return
    
    def getPop(self, idx = -1):
        if idx == -1:
            return self.pop
        else :
            return self.pop[idx]
    
    def appendPop(self, cityList):
        self.pop.append(cityList)
        self.curPopSize += 1
        return
    
    def removePop(self, idx):
        if isinstance(idx, int):
            del self.pop[idx]
        else:
            self.pop.remove(idx)
        self.curPopSize -= 1
        return
    
    def changePop(self, popList):
        self.pop = popList
        return
        
    def getGeneration(self):
        return self.generation
    
    def changeGeneration(self, num):
        self.generation = num
        return
    
    def getMaxPopSize(self):
        return self.maxPopSize
    
    def changeMaxPopSize(self, size):
        self.maxPopSize = size
        return
    
    def getCurPopSize(self):
        return self.curPopSize
    
    def changeCurPopSize(self, size):
        self.curPopSize = size
        return
    
    def getMutationRate(self):
        return self.mutationRate
            
    def selection(self): # 룰렛휠
        temp = self.pop[0:self.maxPopSize]    # 각 세대의 selection 확률을 분리
        populationFitness = sum([chromosome.getFitness() for chromosome in temp])
        #print(populationFitness)
        chromosome_probabilities = [chromosome.fitness / populationFitness for chromosome in temp]
        chromosome_probabilities = 1 - np.array(chromosome_probabilities)
        chromosome_probabilities /= chromosome_probabilities.sum() # 정규화
        """                                   # 새롭게 append 된 것을 포함해서 확률을 계산
        populationFitness = sum([chromosome.getFitness() for chromosome in self.pop])
        chromosome_probabilities = [chromosome.fitness / populationFitness for chromosome in self.pop]
        chromosome_probabilities = 1 - np.array(chromosome_probabilities)
        chromosome_probabilities /= chromosome_probabilities.sum() # 정규화
        """
        return np.random.choice(self.pop[0:self.maxPopSize], p=chromosome_probabilities)
        
    def crossover(self, parent1, parent2):
        
        # ======================ORDER CROSSOVER=======================
        child = CityList()
        firstIndex = random.randint(0,len(parent1)-1)
        secondIndex = random.randint(firstIndex, len(parent1)-1)
        innerSet = parent1[firstIndex:secondIndex]
        startSet = []
        endSet = []
        for _, value in enumerate([item for item in parent2 if item not in innerSet]):
            if len(startSet)<firstIndex:
                startSet.append(value)
            else:
                endSet.append(value)
        child.changeChromo(startSet + innerSet + endSet)
        child.appendChromo(child.getChromo()[0]) # reproduction 함수에서 제거한 list의 마지막 원소를 다시 추가
        
        if random.randrange(0, 100) < self.mutationRate: #Mutation
            child.mutation()
    
        child.calculateFitness()
        
        # ==========================PMX==========================
        """child = CityList()
        child.chromosomes = []
        size = len(parent1)
        p1, p2 = [0] * size, [0] * size
        #print(len(parent1), len(p1))
        for i in range(size) :
            p1[parent1[i]] = i
            p2[parent1[i]] = i
        point1 = random.randint(0,size)
        point2 = random.randint(0, size - 1)
        if point2 >= point1 :
            point2 += 1
        else :
            point1, point2 = point2, point1
        for i in range(point1, point2) :
            temp1 = parent1[i]
            temp2 = parent2[i]
            parent1[i], parent1[p1[temp2]] = temp2, temp1
            parent2[i], parent2[p2[temp1]] = temp1, temp2
            p1[temp1], p1[temp2] = p1[temp2], p1[temp1]
            p2[temp1], p2[temp2] = p2[temp2], p2[temp1]
        child.chromosomes = parent1[:min(point1, point2)] + parent1[min(point1,point2):max(point1, point2)] + parent1[max(point1,point2):]
        child.appendChromo(child.getChromo()[0]) # reproduction 함수에서 제거한 list의 마지막 원소를 다시 추가
        
        if random.randrange(0, 100) < self.mutationRate: #Mutation
            child.mutation()
        child.calculateFitness()"""
        return child
        
    def reproduction(self): #부모 선택
        parent1 = self.selection().getChromo()[0:len(self.selection().getChromo())-1] # 출발점으로 돌아오는 지점을 빼고 계산
        parent2 = self.selection().getChromo()[0:len(self.selection().getChromo())-1]
        while True:
            if parent1 == parent2:
                parent2 = self.selection().getChromo()[0:len(self.selection().getChromo())-1]
            else:
                break
        return self.crossover(parent1, parent2)
    
    def findBest(self):
        bestFitness = math.inf
        best = CityList()
        for chromosome in self.pop:
            if chromosome.getFitness() < bestFitness:
                bestFitness = chromosome.getFitness()
                best = chromosome
        return best
    

class GA:
    threshold = -1 # 역치, threshold보다 fitness가 큰 경우 자동적으로 삭제
    #pop = Population()
    #maxPopSize = 20
    #bestPath = []
    #bestPop = CityList()
    
    def __init__(self, size = 20, chromoList = None): # 인구수는 여기서 변경
        #print(type(size), type(chromoList))
        if chromoList == None:
            self.pop = Population()
        else:
            self.pop = Population(size, chromoList)
        self.maxPopSize = size
        self.bestPath = []
        self.bestPop = CityList()
        self.bestFitness = float('inf')
        
        self.pop.changeMaxPopSize(self.maxPopSize)
            
        
    def loop(self, num):
        start = time.time()
        startFitness = self.pop.findBest().getFitness()
        finalFitness = math.inf
        self.threshold = 12000
       
        for i in range(num):
            print("---------------------------------------------------------------")
            self.pop.changeGeneration(self.pop.getGeneration() + 1)  #세대수 증가
            print("GENERATION : ", self.pop.getGeneration())
            print("THRESHOLD : ", self.threshold)
            print("POPSIZE : ", self.pop.getCurPopSize())
            
            for j in range(self.maxPopSize):                        #새로운 세대 생성
                self.pop.appendPop(self.pop.reproduction())
                
            #토너먼트 대치
            newPop = []
            for i in range(self.maxPopSize):
                if self.pop.getPop()[i*2].getFitness() > self.pop.getPop()[i*2 + 1].getFitness():
                    newPop.append(self.pop.getPop()[i*2 + 1])
                else:
                    newPop.append(self.pop.getPop()[i*2])
            self.pop.changePop(newPop)
            self.pop.changeCurPopSize(self.pop.getCurPopSize() / 2)
            
            
            self.bestPop = self.pop.findBest()     
            self.bestPop.printChromo(1)
            finalFitness = self.bestPop.getFitness()
            
        end = time.time()
        print("TIME : ", end - start)
        print("RES_FITNESS : ", startFitness, " -> ", finalFitness)
        print("CURPOPSIZE : ", self.pop.getCurPopSize())
                
    def printGA(self, opt = 0): #0 : 모든 fitness, 염색체 출력, 1 : fitness만 출력
        self.pop.printPop(opt)
        return
    
    def printBest(self, opt = 0): #0 : 모든 fitness, 염색체 출력, 1 : fitness만 출력 
        self.bestPop.printChromo(opt)
        return
    
    def getBestRoute(self):
        return self.bestPop.getChromo()
    
GC = GenerateChromo()
chromoList = []
popSize = 70                # 인구수는 여기서 설정
for i in range(popSize):
    chromoList.append(GC.generate())

chromoList_idx = []
for i in chromoList:
    chromoList_idx.append(xyToIdx(cityCoordinates, i))
    
test = GA(popSize, chromoList_idx)
test.loop(20000)             # 세대수는 여기서 설정
print("-----------------------------------------------")
print("RES : \n")
test.printGA(1)

vis = Visualizer(test.getBestRoute())
vis.visualize()

df = pd.DataFrame(test.getBestRoute()[0:1000])
df.to_csv('solution_07.csv', header = False, index = False)